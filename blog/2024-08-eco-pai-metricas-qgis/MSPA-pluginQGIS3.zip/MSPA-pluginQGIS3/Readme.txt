Please first read the document MSPA-pluginQGIS3.pdf 
and then run the appropriate installation script.
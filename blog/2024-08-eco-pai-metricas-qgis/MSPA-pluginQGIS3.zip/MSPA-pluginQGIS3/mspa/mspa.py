# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Mspa
                                 A QGIS plugin
 Morphological Spatial Pattern Analysis
                              -------------------
        begin                : 2022-04-12
        git sha              : $Format:%H$
        copyright            : (C) 2022 by European Commission JRC
        email                : peter.vogt@ec.europa.eu
	email                : diego.migliavacca@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtCore import QSettings, QTranslator, qVersion, QCoreApplication, QFileInfo, Qt
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QProgressDialog, QPushButton
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsRasterLayer, QgsProject
from . import resources
from .mspa_dialog import MspaDialog
import os, subprocess, urllib.request, urllib.error, urllib.parse
from osgeo import osr, gdal
try:
    from gdalconst import *
except:
    from osgeo.gdalconst import *


class Mspa:
    """QGIS Plugin Implementation."""
    def __init__(self, iface):
        """Constructor."""
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'Mspa_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = MspaDialog()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&MSPA')
        self.toolbar = self.iface.addToolBar(u'Mspa')
        self.toolbar.setObjectName(u'Mspa')

        self.VERSION = 2.0
        self.projection = None
        self.geoinformation = None


    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API."""
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('Mspa', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar."""

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)
        return action


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/mspa/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Mspa'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&MSPA'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar


    @staticmethod
    def openPdfFile(filename):
        try:
            os.startfile(filename)
        except AttributeError:
            subprocess.call(['xdg-open', filename])


    @staticmethod
    def getErrorMessageBox(msg):
        mb = QMessageBox()
        mb.setIcon(QMessageBox.Critical)
        mb.setText(msg)
        mb.setWindowTitle("Error")
        mb.setStandardButtons(QMessageBox.Close)
        mb.exec_()


    def endOfProcessing(self, str):
        self.progdialog.hide()
        self.getErrorMessageBox(str)


    def saveAndLoadImageIntoQgis(self, inputFile, graphg, eew, t, i):
        path = os.path.dirname(inputFile)
        if os.path.isdir(path):
            os.chdir(path)

        raster = self.plugin_dir + '/out.tif'
        dataset = gdal.Open(raster, GA_Update)
        if dataset is None:
            self.endOfProcessing("Unable to load the layer")
        else:
            if inputFile.lower().endswith('.tif'):
                inputFile = inputFile[:-4].rsplit('/', 1)[-1]
            elif inputFile.lower().endswith('.tiff'):
                inputFile = inputFile[:-5].rsplit('/', 1)[-1]

            dataset.SetProjection(self.projection)
            dataset.SetGeoTransform(self.geoinformation)
            if self.gcpCount != 0:
                dataset.SetGCPs(self.gcp, self.gcpProjection)
            parameters = str(graphg + "_" + eew + "_" + t + "_" + i)
            docname = str(inputFile) + "_" + parameters + ".tif"
            dataset.SetMetadataItem("TIFFTAG_DOCUMENTNAME", docname)
            dataset.SetMetadataItem("TIFFTAG_IMAGEDESCRIPTION", "GTB_MSPA, https://forest.jrc.ec.europa.eu/en/activities/lpa/gtb/ " + parameters)
            dataset = None
            self.progdialog.hide()
            self.dlg.close()

            booly = True
            while booly:
                mb = QMessageBox()
                mb.setWindowTitle("GeoTiff image processed successfully!")
                mb.setIcon(QMessageBox.Information)
                mb.setText("Please select:\nSave GeoTiff: Save MSPA image & load layer into QGIS.\nShow Details: MSPA parameters used for processing.\nClose: Exit and do NOT save/load the new MSPA layer.\n")
                mb.addButton(QPushButton('Save GeoTiff'), QMessageBox.AcceptRole)
                mb.setDetailedText("The image analysis was processed against the following parameters:\nFGconn: " + graphg + "\nEdgeWidth: " + eew + "\nTransition: " + t + "\nIntext: " + i)
                mb.addButton(QMessageBox.Close)
                mb.setDefaultButton(QPushButton('Save GeoTiff'))
                clicked = mb.exec_()
                if clicked == QMessageBox.Close:
                    booly = False
                    if os.path.isfile(self.plugin_dir + '/out.tif'):
                        os.remove(self.plugin_dir + '/out.tif')
                elif clicked == QMessageBox.AcceptRole:
                    selectedDirectory = str(QFileDialog.getExistingDirectory(self.dlg, "Select directory"))
                    movedFile = selectedDirectory + "/" + docname

                    driver = gdal.GetDriverByName("GTiff")
                    dataset_new = gdal.Open(raster)
                    driver.CreateCopy(movedFile, dataset_new, 1, ['COMPRESS=LZW'])
                    dataset_new = None
                    if os.path.isfile(movedFile):
                        booly = False
                        fileInfo = QFileInfo(movedFile)
                        path = fileInfo.filePath()
                        baseName = fileInfo.baseName()
                        layer = QgsRasterLayer(path, baseName)
                        if layer.isValid() is True:
                            QgsProject.instance().addMapLayer(layer)
                            if os.path.isfile(self.plugin_dir + '/out.tif'):
                                os.remove(self.plugin_dir + '/out.tif')
                        else:
                            os.remove(movedFile)
                            self.endOfProcessing("Unable to load the layer")
                    else:
                        self.endOfProcessing("The file couldn't be saved in the selected directory. Please check if the directory is writable or select another directory")


    def checkImage(self):
        self.dlg.startButton.setEnabled(False)
        filename = self.dlg.showPath.text()
        if filename == "":
            self.endOfProcessing("Please load a mspa-compliant image")
        else:
            if filename.lower().endswith(('.tiff', '.tif')):
                dataset = gdal.Open(filename, GA_ReadOnly)
                self.projection = dataset.GetProjection()
                if self.projection == "":
                    self.endOfProcessing("The image has no projection. Please load a mspa-compliant image")
                else:
                    self.geoinformation = dataset.GetGeoTransform()
                    self.gcpCount = dataset.GetGCPCount()
                    self.gcp = dataset.GetGCPs()
                    self.gcpProjection = dataset.GetGCPProjection()
                    nbands = dataset.RasterCount
                    band = dataset.GetRasterBand(1)
                    bandtype = gdal.GetDataTypeName(band.DataType)
                    xsize = dataset.RasterXSize
                    ysize = dataset.RasterYSize
                    if nbands != 1:
                        self.endOfProcessing("The image is not a single band image. Please load a mspa-compliant image")
                    elif bandtype != "Byte":
                        self.endOfProcessing("The band type is not Byte, it is " + bandtype + ". Please load a mspa-compliant image")
                    elif xsize * ysize > 65000000:
                        self.endOfProcessing("The image is bigger than 65 MB. Please load a mspa-compliant image")
                    elif xsize < 50 and ysize < 50:
                        self.endOfProcessing("The x and/or the y size of the image is smaller than 50 pixels. Please load a mspa-compliant image")
                    else:
                        maxval = int(band.ComputeRasterMinMax()[1])
                        if maxval > 2:
                            self.endOfProcessing("The max value for the band in the dataset is bigger than 2 (" + str(maxval) + "). Please load a mspa-compliant image")
                        elif maxval == 2:
                            secondhistval = band.GetDefaultHistogram()[3][1]
                            if secondhistval != 0:
                                driver = gdal.GetDriverByName("GTiff")
                                driver.CreateCopy(self.plugin_dir + '/out.tif', dataset, 1, ['TILED=NO', 'PROFILE=BASELINE', 'COMPRESS=LZW'])
                                self.progdialog.hide()
                                self.dlg.startButton.setEnabled(True)
                            else:
                                self.endOfProcessing("The histogram values for the band in the dataset are not mspa-compliant. Please load a mspa-compliant image")
                dataset = None
            else:
                self.endOfProcessing("The image is not a tif file. Please load a mspa-compliant image")
            path = os.path.dirname(filename)
            if os.path.isdir(path):
                os.chdir(path)


    def startProgDialog(self):
        self.progdialog = QProgressDialog()
        self.progdialog.setWindowTitle("Loading...")
        self.progdialog.setCancelButtonText("Cancel")
        self.progdialog.setMinimum(0)
        self.progdialog.setMaximum(0)
        self.progdialog.setWindowModality(Qt.WindowModal)
        self.progdialog.show()
        if self.progdialog.wasCanceled():
            self.progdialog.hide()


    def run(self):
        """Run method that performs all the real work"""
        # show the dialog
        self.dlg.show()

        try:
            target_url = 'https://ies-ows.jrc.ec.europa.eu/gtb/GTB/MSPA-plugin/version_mspaQGIS3plugin.txt'
            data = urllib.request.urlopen(target_url)
            for line in data:
                if float(line) > self.VERSION:
                    mb = QMessageBox()
                    mb.setWindowTitle("New version of the plugin available")
                    mb.setIcon(QMessageBox.Information)
                    mb.setText("There is a new version of the plugin available. Visit https://forest.jrc.ec.europa.eu/en/activities/lpa/mspa/ to get your copy of version " + line)
                    mb.setStandardButtons(QMessageBox.Close)
                    mb.exec_()
        except:
            pass

        self.dlg.pluginguideButton.clicked.connect(lambda: self.openPdfFile(self.plugin_dir + "/MSPA-pluginQGIS3.pdf"))
        self.dlg.mspaguideButton.clicked.connect(lambda: self.openPdfFile(self.plugin_dir + "/MSPA_Guide.pdf"))
        self.dlg.selectButton.clicked.connect(lambda: self.dlg.showPath.setText(QFileDialog.getOpenFileName()[0]))
        self.dlg.selectButton.clicked.connect(lambda: self.startProgDialog())
        self.dlg.selectButton.clicked.connect(lambda: self.checkImage())

        self.dlg.startButton.clicked.connect(lambda: self.startProgDialog())
        self.dlg.startButton.clicked.connect(lambda: os.chdir(self.plugin_dir))
        self.dlg.startButton.clicked.connect(lambda: os.system("mspa_win64.exe -i out.tif -o out.tif -graphfg " + self.dlg.comboBox_1.currentText() + " -eew " + self.dlg.comboBox_2.currentText() + " -transition " + self.dlg.comboBox_3.currentText() + " -internal " + self.dlg.comboBox_4.currentText() + " -odir ./"))
        self.dlg.startButton.clicked.connect(lambda: self.saveAndLoadImageIntoQgis(self.dlg.showPath.text(), self.dlg.comboBox_1.currentText(), self.dlg.comboBox_2.currentText(), self.dlg.comboBox_3.currentText(), self.dlg.comboBox_4.currentText()))

# -*- coding: utf-8 -*-
"""
/***************************************************************************
 MspaDialog
                                 A QGIS plugin
 Morphological Spatial Pattern Analysis
                             -------------------
        begin                : 2018-06-19
        git sha              : $Format:%H$
        copyright            : (C) 2017 by European Commission JRC
        email                : peter.vogt@ec.europa.eu
		email                : diego.migliavacca@ext.ec.europa.eu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
from PyQt5 import uic, QtWidgets


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'mspa_dialog_base.ui'))


class MspaDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(MspaDialog, self).__init__(parent)
        self.centerOnScreen()
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)


    def centerOnScreen(self):
        '''Centers the window on the screen.'''
        resolution = QtWidgets.QDesktopWidget().screenGeometry()
        self.move((resolution.width() // 2) - (self.frameSize().width() // 2), (resolution.height() // 2) - (self.frameSize().height() // 2))


    def closeEvent(self, event):
        self.selectButton.clicked.disconnect()
        self.startButton.clicked.disconnect()
        self.showPath.clear()
        self.comboBox_1.setCurrentIndex(0)
        self.comboBox_2.setCurrentIndex(0)
        self.comboBox_3.setCurrentIndex(0)
        self.comboBox_4.setCurrentIndex(0)
        self.startButton.setEnabled(False)

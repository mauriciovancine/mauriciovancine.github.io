@echo off
Rem Installation of MSPA-plugin for QGIS3
set qplug="%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\mspa\"
Set _os_bitness=64
IF %PROCESSOR_ARCHITECTURE% == x86 (
  IF NOT DEFINED PROCESSOR_ARCHITEW6432 Set _os_bitness=32
  )
  
if %_os_bitness% == 32 (
  echo This plugin is only supported for MS-Windows 64bit 
  ) else (
	if exist "%ProgramFiles%\QGIS 3.*" (
	  md %qplug% 2>NUL
	  xcopy mspa %qplug% /Y /E /R /Q
	  xcopy MSPA_Guide.pdf %qplug% /Y /R /Q
	  xcopy MSPA-pluginQGIS3.pdf %qplug% /Y /R /Q
	  echo MSPA-plugin is now installed. Please restart QGIS and follow the
	  echo instructions in the MSPA-pluginQGIS3.pdf to activate the new plugin.
	  cd %qplug%
	  start MSPA-pluginQGIS3.pdf
	  ) else (
	  echo QGIS3 was not found on your system. Please download and  
	  echo install the latest QGIS3 version to its default location.
	  start http://www.qgis.org/en/site/
	  )
)
pause
